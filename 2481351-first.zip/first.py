'''
print("My python code")

a=2
b=5
print(a,end="#")
print(a,b,sep="@",end="*")
print("abc")

a,b,c=2,3,4
print(a,b,c,end="33")
print(b,a,sep="56")
print(a,sep="%")

print("hello")
#print("xyz")
'''
"""
a=9
print("a : ",a)
print(type(a))
a=3.4
print("a : ",a)
print(type(a))
a="abc"
print("a : ",a)
print(type(a))

"""
"""
a,b,c=2,3,2
print(a,id(a))
print(b,id(b))
print(c,id(c))
"""
"""
a=5
print(a)
print("a : ",id(a))

"""
"""
a,b=958668567,-957486767876
print(a,type(a))
print(b,type(b))

a,b=95866.8567,-95748.6767876
print(a,type(a))
print(b,type(b))

#a=5+9j
a=complex(3,5)
print(a)
print(type(a))
print(a.real,a.imag)

"""
#string data type
"""
x,y,z,w='abc',"abc",'''abc'''
print(x,type(x))

print(y,type(y))

print(z,type(z))

print(w,type(w))

"""

"""
a="xyz"
print(a,type(a))
print(a[0],a[-3])

print(a[1],a[-2])

print(a[2],a[-1])
"""
"""
a,b="aaa","bbb"
print(a,type(a))
print(b,type(b))
print(a+b)
#print(a-b)
print(a*3)
#print(a/b)
"""


#basic operations on string

a="proGRAmminG lanGUage"
print(a,type(a))

print(a.upper())
print(a.lower())
print(a.capitalize())
print(a.title())












































































































