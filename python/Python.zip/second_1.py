#a=[4,23,6.7,"abc",5+9j,True]
a=list((4,2,"qwerty",89))
print(a,type(a))
print(a[1],a[-3],a[-1],a[2])
print(a[2][3])
